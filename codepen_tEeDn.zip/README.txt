A Pen created at CodePen.io. You can find this one at http://codepen.io/ElmahdiMahmoud/pen/tEeDn.

 Add to cart fly effect with jQuery.